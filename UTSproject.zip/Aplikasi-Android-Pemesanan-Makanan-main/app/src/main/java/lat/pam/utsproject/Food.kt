package lat.pam.utsproject

data class Food(
    val name: String,
    val description: String,
    val imageResourceId: Int
)